#pragma once
class App
{
public:
	App() = default;
	void run();
};

