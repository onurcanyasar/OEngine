﻿#pragma once
#include "../Systems/System.h"
class SystemManager
{

private:
	std::vector<System*> systems;

};