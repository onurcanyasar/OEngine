#include "ClickToMoveSystem.h"

#include <SDL_mouse.h>


void ClickToMoveSystem::update()
{
	auto& trans = entity_memory_pool_->getComponent<Transform>(0);
	

}
